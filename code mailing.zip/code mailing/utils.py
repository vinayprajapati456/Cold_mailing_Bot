import time
import csv
from datetime import datetime

def rate_limit_wait(seconds):
    print(f"Waiting {seconds} seconds to respect rate limit...")
    time.sleep(seconds)

def log_email(contact_email, status):
    with open("email_log.csv", mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([datetime.now(), contact_email, status])
