# EMAIL = "golukumarprajpati76@gmail.com"
# APP_PASSWORD = "Vinay@1456"


EMAIL = "golukumarprajapati76@gmail.com"
APP_PASSWORD = "rswt ejbh pjlt thdn"
RATE_LIMIT_SECONDS = 60  # Wait time between emails
RESUME_PATH = "Vinay_Prajapati.pdf"
