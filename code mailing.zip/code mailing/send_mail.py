import pandas as pd
import yagmail
from jinja2 import Template
import schedule
import time

from config import EMAIL, APP_PASSWORD, RATE_LIMIT_SECONDS, RESUME_PATH
from utils import rate_limit_wait, log_email

def load_template(path):
    with open(path, "r") as f:
        return Template(f.read())

def send_emails():
    df = pd.read_csv("contacts.csv")
    template = load_template("templates/sde_template.txt")
    yag = yagmail.SMTP(EMAIL, APP_PASSWORD)

    for _, row in df.iterrows():
        content = template.render(
            name=row['name'],
            company=row['company'],
            tech_stack=row['tech_stack']
        )
        subject = content.splitlines()[0].replace("Subject: ", "")
        body = "\n".join(content.splitlines()[1:])

        try:
            yag.send(
                to=row['email'],
                subject=subject,
                contents=body,
                attachments=RESUME_PATH
            )
            print(f"✅ Email sent to {row['name']} at {row['email']}")
            log_email(row['email'], "Sent")
        except Exception as e:
            print(f"❌ Failed to send email to {row['email']}: {e}")
            log_email(row['email'], f"Failed: {e}")
        rate_limit_wait(RATE_LIMIT_SECONDS)

# --- SCHEDULING EXAMPLE ---
if __name__ == "__main__":
    # send_emails()
    print("📬 Cold Email Bot Initialized...")
    # Run once at a specific time (e.g., 10:30 AM)
    schedule.every().day.at("10:30").do(send_emails)

    while True:
        schedule.run_pending()
        time.sleep(1)
        # Allow user to input a specific time for scheduling
        user_time = input("⏰ Enter the time to send emails (HH:MM, 24-hour format): ")
        try:
            schedule.every().day.at(user_time).do(send_emails)
            print(f"📅 Emails will be sent after {user_time}.")
        except Exception as e:
            print(f"❌ Invalid time format: {e}")





### This script is designed to send cold emails using a template and a CSV file containing contact information.           \
#AND THIS CODE  AS SAME  WORKING , WE CAN USE ALSO THIS CODE
# import pandas as pd
# import yagmail
# from jinja2 import Template

# # Load contacts
# df = pd.read_csv("contacts.csv")

# # Setup Gmail client (ensure you've enabled "Less Secure Apps" or App Passwords for your Gmail)
# sender_email = "your_email@gmail.com"
# app_password = "your_app_password_here"  # Use app-specific password
# yag = yagmail.SMTP(sender_email, app_password)

# # Load the template
# with open("templates/sde_template.txt", "r") as f:
#     template = Template(f.read())

# # Loop through contacts and send email
# for index, row in df.iterrows():
#     content = template.render(name=row['name'], company=row['company'], tech_stack=row['tech_stack'])
    
#     subject_line = content.splitlines()[0].replace("Subject: ", "")
#     body = "\n".join(content.splitlines()[1:])

#     try:
#         yag.send(
#             to=row['email'],
#             subject=subject_line,
#             contents=body,
#             attachments="Vinay_Prajapati.pdf"  # Make sure this file exists
#         )
#         print(f"Email sent to {row['name']} ({row['email']})")
#     except Exception as e:
#         print(f"Failed to send email to {row['email']}: {str(e)}") 